define(['jquery'], function($) {
return {
  init: function(){
			$('#myTab a:last').tab('show');
		}
	};
});